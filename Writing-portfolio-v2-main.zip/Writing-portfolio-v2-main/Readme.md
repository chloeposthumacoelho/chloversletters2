# My writing portfolio-v2
<img src="./assets/screenshot.png" alt="project">

- Live Site URL: [https://toriola-writing-portfolio.netlify.app/](https://toriola-writing-portfolio.netlify.app/)